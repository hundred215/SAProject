package com.namleesin.smartalert.data;

public class KeywordData
{
	public String keywordata = null;
	public int keyword_status = 0;

	public String getKeywordata() {
		return keywordata;
	}

	public KeywordData setKeywordata(String keywordata) {
		this.keywordata = keywordata;
		return this;
	}

	public int getKeywordstatus() {
		return keyword_status;
	}

	public KeywordData setKeywordstatus(int keywordstatus) {
		this.keyword_status = keywordstatus;
		return this;
	}
}
