package com.namleesin.smartalert.data;

public class PackData 
{
	public String packagename = null;
	public int package_status = 0;
}
