package com.namleesin.smartalert.main;

public class MainValue 
{
	public static final int RES_SPLASH_SCREEN 				= 0;
	public static final int RES_GUIDE_WIZARD					= 1;
	public static final int RES_ALERT_SETTING					= 2;
	public static final int RES_ALERT_ACCESS					= 3;
	public static final int RES_SL_SETTING						= 4;

	public static final int MENU_ITEM_SPAM_ALERT				= 0;
	public static final int MENU_ITEM_LIKE_ALERT				= 1;

	public static final String ACTIVITY_TYPE  					= "activity_type";
	public static final int TYPE_INIT_NOTI_SETTING			= 0;
	public static final int TYPE_MENU_NOTI_SETTING			= 1;
	public static final String SET_INDEX_NUMBER				= "index_number";
}
