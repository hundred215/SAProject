package com.namleesin.smartalert.data;

import android.graphics.Bitmap;

public class NotiData
{
	public String packagename = null;
	public String titletxt = null;
	public String subtxt = null;
	public String notiid = null;
	public String notikey = null;
	public String notitime = null;
	public int status = 0;
	public String filter_word = null;
	public int urlstatus = 0;
	public Bitmap picturebitmap = null;
}
